//
//  ViewController.swift
//  ToDoApp
//
//  Created by Varun Ambulgekar on 09/12/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var numberField: UITextField!
    
    @IBAction func submitButtonTapped(_ sender: UIButton) {
        // Validate the inputs
        guard let name = nameField.text, !name.isEmpty,
              let numberText = numberField.text, !numberText.isEmpty,
              let number = Int(numberText) else {
            showAlert(message: "Both Name and Number are required. The Number must be valid.")
            return
        }
        
        // Proceed to the To-Do List screen if validation passes
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let toDoVC = storyboard.instantiateViewController(withIdentifier: "ToDoViewController") as! ToDoViewController
        toDoVC.userName = name
        toDoVC.userNumber = number
        navigationController?.pushViewController(toDoVC, animated: true)
    }
    
    private func showAlert(message: String) {
        let alert = UIAlertController(title: "Validation Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

