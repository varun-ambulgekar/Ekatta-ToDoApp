//
//  ToDoViewController.swift
//  ToDoApp
//
//  Created by Varun Ambulgekar on 09/12/24.
//

import UIKit
import CoreData

class ToDoViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var taskField: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    var userName: String = ""
    var userNumber: Int = 0
    var tasks: [Task] = []
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLabel.text = "Welcome, \(userName)"
        numberLabel.text = "Number: \(userNumber)"
        tableView.dataSource = self
        tableView.delegate = self
        fetchTasks()
    }
    
    @IBAction func addTaskTapped(_ sender: UIButton) {
        guard let taskTitle = taskField.text, !taskTitle.isEmpty else { return }
        
        // Create a new task and associate it with the current user
        let newTask = Task(context: context)
        newTask.title = taskTitle
        newTask.userName = userName  // Associate task with the current user's name
        saveTasks()
        
        tasks.append(newTask)
        tableView.reloadData()
        taskField.text = ""
    }
    
    // Fetch tasks for the current user only
    private func fetchTasks() {
        let request: NSFetchRequest<Task> = Task.fetchRequest()
        
        // Filter tasks by userName
        request.predicate = NSPredicate(format: "userName == %@", userName)
        
        do {
            tasks = try context.fetch(request)
        } catch {
            print("Error fetching tasks: \(error)")
        }
    }
    
    // Save tasks to Core Data
    private func saveTasks() {
        do {
            try context.save()
        } catch {
            print("Error saving tasks: \(error)")
        }
    }
    
    // Table View Data Source Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskCell") ?? UITableViewCell(style: .default, reuseIdentifier: "TaskCell")
        cell.textLabel?.text = tasks[indexPath.row].title
        return cell
    }
    
    // Swipe-to-delete functionality
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { _, _, completionHandler in
            let taskToRemove = self.tasks[indexPath.row]
            self.context.delete(taskToRemove)
            self.tasks.remove(at: indexPath.row)
            self.saveTasks()
            tableView.deleteRows(at: [indexPath], with: .automatic)
            completionHandler(true)
        }
        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
}

